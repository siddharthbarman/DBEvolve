﻿-- DBEVOLVE: NO_TRANSACTION

create view ReconStatusView as
select * from ReconStatus;   
GO

create view ReconStatusView2 as
select * from ReconStatus;


