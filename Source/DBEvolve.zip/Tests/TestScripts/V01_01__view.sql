﻿create view ReconStatusView as
select * from ReconStatus;